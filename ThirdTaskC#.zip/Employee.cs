using System;
public abstract class Employee
{
    protected string name;
    protected int id;
    protected string address;
    protected double salary;

    public Employee()
    {
        this.name = "";
        this.id = 0;
        this.address = "";
        this.salary = 0.0;
    }

    public Employee(string name, int id, string address, double salary)
    {
        this.name = name;
        this.id = id;
        this.address = address;
        this.salary = salary;
    }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int ID
    {
        get { return id; }
        set { id = value; }
    }

    public string Address
    {
        get { return address; }
        set { address = value; }
    }

    public double Salary
    {
        get { return salary; }
        set { salary = value; }
    }

    public abstract void PrintData();
}
