using System;

public class Doctor : Employee
{
    protected int numOfPatients;

    public Doctor()
    {
        numOfPatients = 0;
    }

    public Doctor(string name, int id, string address, double salary, int numOfPatients)
        : base(name, id, address, salary)
    {
        this.numOfPatients = numOfPatients;
    }

    public int NumOfPatients
    {
        get { return numOfPatients; }
        set { numOfPatients = value; }
    }

    public override void PrintData()
    {
        if (numOfPatients > 10)
        {
            salary += 2000;
        }
        else if (numOfPatients >= 5)
        {
            salary += 1000;
        }

        Console.WriteLine($"ID: {ID}, Name: {Name}, Address: {Address}, Salary: {Salary}, NumOfPatients: {NumOfPatients}");
    }
}
