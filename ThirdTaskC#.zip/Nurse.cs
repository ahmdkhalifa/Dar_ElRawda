using System;

public class Nurse : Employee
{
    private int overtime;

    public Nurse()
    {
        overtime = 0;
    }

    public Nurse(string name, int id, string address, double salary, int overtime)
        : base(name, id, address, salary)
    {
        this.overtime = overtime;
    }

    public int Overtime
    {
        get { return overtime; }
        set { overtime = value; }
    }

    public override void PrintData()
    {
        Console.WriteLine($"ID: {ID}, Name: {Name}, Address: {Address}, Salary: {Salary}, Overtime: {Overtime}");
    }
}
