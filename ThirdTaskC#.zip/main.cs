using System;

class Program
{
    static void Main(string[] args)
    {

        Doctor d1 = new Doctor();
        Console.Write("Enter d1 ID: ");
        d1.ID = int.Parse(Console.ReadLine());
        Console.Write("Enter d1 Name: ");
        d1.Name = Console.ReadLine();
        Console.Write("Enter d1 Salary: ");
        d1.Salary = double.Parse(Console.ReadLine());
        Console.Write("Enter d1 Address: ");
        d1.Address = Console.ReadLine();
        Console.Write("Enter d1 NumOfPatients: ");
        d1.NumOfPatients = int.Parse(Console.ReadLine());

        Doctor d2 = new Doctor();
        Console.Write("Enter d2 ID: ");
        d2.ID = int.Parse(Console.ReadLine());
        Console.Write("Enter d2 Name: ");
        d2.Name = Console.ReadLine();
        Console.Write("Enter d2 Salary: ");
        d2.Salary = double.Parse(Console.ReadLine());
        Console.Write("Enter d2 Address: ");
        d2.Address = Console.ReadLine();
        Console.Write("Enter d2 NumOfPatients: ");
        d2.NumOfPatients = int.Parse(Console.ReadLine());


        Nurse n1 = new Nurse();
        Console.Write("\nEnter n1 ID: ");
        n1.ID = int.Parse(Console.ReadLine());
        Console.Write("Enter n1 Name: ");
        n1.Name = Console.ReadLine();
        Console.Write("Enter n1 Salary: ");
        n1.Salary = double.Parse(Console.ReadLine());
        Console.Write("Enter n1 Address: ");
        n1.Address = Console.ReadLine();
        Console.Write("Enter n1 Overtime: ");
        n1.Overtime = int.Parse(Console.ReadLine());

        Nurse n2 = new Nurse();
        Console.Write("\nEnter n2 ID: ");
        n2.ID = int.Parse(Console.ReadLine());
        Console.Write("Enter n1 Name: ");
        n2.Name = Console.ReadLine();
        Console.Write("Enter n2 Salary: ");
        n2.Salary = double.Parse(Console.ReadLine());
        Console.Write("Enter n2 Address: ");
        n2.Address = Console.ReadLine();
        Console.Write("Enter n2 Overtime: ");
        n2.Overtime = int.Parse(Console.ReadLine());

        Console.WriteLine("\nD1 Data is:");
        d1.PrintData();

        Console.WriteLine("\nD2 Data is:");
        d2.PrintData();

        Console.WriteLine("\nN1 Data is:");
        n1.PrintData();

        Console.WriteLine("\nN2 Data is:");
        n2.PrintData();
    }
}