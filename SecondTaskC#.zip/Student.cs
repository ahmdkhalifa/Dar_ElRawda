using System;

namespace SecondTask
{
class Student
  {
    int id;
    int total;
    string name;
    string eval;

    public Student()
    {
      id=0;
      total=0;
      name="";
      eval="";
    }

    public Student(int ID,int TOTAL,string Name)
    {
      id=ID;
      total=TOTAL;
      name=Name;
    }

    public int ID
    {
      set{id=value;}
      get{return id;}
    }

    public string Name
    {
      set{name=value;}
      get{return name;}
    }

    public int TOTAL
    {
      set{total=value;}
    }

    public string CalcEval()
    {
      if(total<0 || total >100)
      {
        return eval="Error";
      }
      else if(total >=85) return eval="A";
      else if(total >=75) return eval="B";
      else if(total >=65) return eval="C";
      else if(total >=50) return eval="D";
      else if(total < 50) return eval="F";
      return eval="Error";
    }
    public void PrintData()
    {
      Console.WriteLine("Name :" + name);
      Console.WriteLine("id :" + id);
      Console.WriteLine("total :" + total);
      Console.WriteLine("Evaluation :" + CalcEval());
      Console.WriteLine("*****************************");


      
    }

  }
}