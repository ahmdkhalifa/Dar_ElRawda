using System;
namespace SecondTask
{
class Program
  {
  public static void Main (string[] args)
    {
    for(int i=0; i<3; i++)
      {
          Console.Write ("Enter Student ID :");
          int ID = int.Parse(Console.ReadLine());
          Console.Write ("Enter Student Name :");
          string name = Console.ReadLine();
          Console.Write ("Enter Student total:");
          int total = int.Parse(Console.ReadLine());

    Student S1 = new Student(ID,total,name);
        S1.PrintData();
        
        

      }
    }
  }
}