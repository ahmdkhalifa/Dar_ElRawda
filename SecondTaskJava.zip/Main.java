import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter Student ID:");
            int ID = Integer.parseInt(input.nextLine());
            System.out.println("Enter Student Name:");
            String name = input.nextLine();
            System.out.println("Enter Student total:");
            int total = Integer.parseInt(input.nextLine());

            Student S1 = new Student(ID,total,name);
             S1.printData();
        }
    }
}
