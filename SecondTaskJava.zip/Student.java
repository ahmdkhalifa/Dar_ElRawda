class Student {
    int id;
    int total;
    String name;
    String eval;

    public Student() {
        id = 0;
        total = 0;
        name = "";
        eval = "";
    }

    public Student(int ID, int TOTAL, String Name) {
        id = ID;
        total = TOTAL;
        name = Name;
    }

    public int getID() {
        return id;
    }

    public void setID(int ID) {
        id = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        name = Name;
    }

    public int getTOTAL() {
        return total;
    }

    public void setTOTAL(int TOTAL) {
        total = TOTAL;
    }

    public String calcEval() {
        if (total < 0 || total > 100) {
            return eval = "Error";
        } else if (total >= 85) {
            return eval = "A";
        } else if (total >= 75) {
            return eval = "B";
        } else if (total >= 65) {
            return eval = "C";
        } else if (total >= 50) {
            return eval = "D";
        } else if (total < 50) {
            return eval = "F";
        }
        return eval = "Error";
    }

    public void printData() {
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Total: " + total);
        System.out.println("Evaluation: " + calcEval());
        System.out.println("*****************************");
    }
}