public class Nurse extends Employee {
    private int overtime;

    public Nurse() {
        super();
        this.overtime = 0;
    }

    public Nurse(String name, int id, String address, double salary, int overtime) {
        super(name, id, address, salary);
        this.overtime = overtime;
    }

    public int getOvertime() {
        return overtime;
    }

    public void setOvertime(int overtime) {
        this.overtime = overtime;
    }

    @Override
    public void printData() {
      if (overtime > 0 ) {
            overtime*=500;
            salary += overtime;
        } 
        System.out.println("ID: " + id + ", Name: " + name + ", Address: " + address +
                           ", Salary: " + salary + ", Overtime: " + overtime);
    }
}
