
public abstract class Employee {
    protected String name;
    protected int id;
    protected String address;
    protected double salary;

    public Employee() {
        this.name = "";
        this.id = 0;
        this.address = "";
        this.salary = 0.0;
    }

    public Employee(String name, int id, String address, double salary) {
        this.name = name;
        this.id = id;
        this.address = address;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public double getSalary() {
        return salary;
    }

    public abstract void printData();
}
