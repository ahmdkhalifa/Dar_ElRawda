public class Doctor extends Employee {
    protected int numOfPatients;

    public Doctor() {
        super();
        this.numOfPatients = 0;
    }

    public Doctor(String name, int id, String address, double salary, int numOfPatients) {
        super(name, id, address, salary);
        this.numOfPatients = numOfPatients;
    }

    public int getNumOfPatients() {
        return numOfPatients;
    }

    public void setNumOfPatients(int numOfPatients) {
        this.numOfPatients = numOfPatients;
    }

    @Override
    public void printData() {
        if (numOfPatients >10) {
            salary += 2000;
        } else if (numOfPatients >= 5) {
            salary += 1000;
        }
        System.out.println("ID: " + id + ", Name: " + name + ", Address: " + address +
                           ", Salary: " + salary + ", NumOfPatients: " + numOfPatients);
    }
}
