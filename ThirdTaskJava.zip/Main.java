import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    
    Doctor d1 = new Doctor();
    System.out.print("Enter d1 ID: ");
    d1.id = scanner.nextInt();
    scanner.nextLine(); 
    System.out.print("Enter d1 Name: ");
    d1.name = scanner.nextLine();
    System.out.print("Enter d1 Salary: ");
    d1.salary = scanner.nextDouble();
    scanner.nextLine(); 
    System.out.print("Enter d1 Address: ");
    d1.address = scanner.nextLine();
    System.out.print("Enter d1 NumOfPatients: ");
    d1.numOfPatients = scanner.nextInt();

            Doctor d2 = new Doctor();
            System.out.print("\nEnter d2 ID: ");
            d2.id = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter d2 Name: ");
            d2.name = scanner.nextLine();
            System.out.print("Enter d2 Salary: ");
            d2.salary = scanner.nextDouble();
            scanner.nextLine(); 
            System.out.print("Enter d2 Address: ");
            d2.address = scanner.nextLine();
            System.out.print("Enter d2 NumOfPatients: ");
            d2.numOfPatients = scanner.nextInt();

            

    
    
            Nurse n1 = new Nurse();
        System.out.print("\nEnter n1 ID: ");
        n1.id = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter n1 Name: ");
        n1.name = scanner.nextLine();
        System.out.print("Enter n1 Salary: ");
        n1.salary = scanner.nextDouble();
        scanner.nextLine(); 
        System.out.print("Enter n1 Address: ");
        n1.address = scanner.nextLine();
        System.out.print("Enter n1 Overtime: ");
        n1.setOvertime(scanner.nextInt());
    
      
      
        Nurse n2 = new Nurse();

    System.out.print("Enter n2 ID: ");
    n2.id = scanner.nextInt();
    scanner.nextLine(); 
    System.out.print("Enter n2 Name: ");
    n2.name = scanner.nextLine();
    System.out.print("Enter n2 Salary: ");
    n2.salary = scanner.nextDouble();
    scanner.nextLine(); 
    System.out.print("Enter n2 Address: ");
    n2.address = scanner.nextLine();
    System.out.print("Enter n2 Overtime: ");
    n2.setOvertime(scanner.nextInt());

    scanner.close();

    
    System.out.println("\nD1 Data is:");
    d1.printData();

    System.out.println("\nD2 Data is:");
    d2.printData();

    System.out.println("\nN1 Data is:");
    n1.printData();

    System.out.println("\nN2 Data is:");
    n2.printData();
  }
}
