import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Enter First Number");
            int Fnum = Integer.parseInt(scanner.nextLine());
            System.out.println("Choose operation");
            char Opr = scanner.nextLine().charAt(0);
            System.out.println("Enter Second Number");
            int Snum = Integer.parseInt(scanner.nextLine());

            switch (Opr) {
                case '+':
                    MyMath.Sum(Fnum, Snum);
                    break;
                case '-':
                    MyMath.Sub(Fnum, Snum);
                    break;
                case '*':
                    MyMath.Mul(Fnum, Snum);
                    break;
                case '/':
                    MyMath.Dev(Fnum, Snum);
                    break;
                case '%':
                    MyMath.Rem(Fnum, Snum);
                    break;
                case '^':
                    MyMath.Pow(Fnum, Snum);
                    break;
            }

            System.out.println("Another Operation?");
            char y = scanner.nextLine().charAt(0);
            if (y != 'T')
                break;
        }
    }
}

