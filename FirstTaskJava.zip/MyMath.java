public class MyMath {
    public static void Sum(int x, int y) {
        System.out.println("Sum = " + (x + y));
    }

    public static void Sub(int x, int y) {
        System.out.println("Sub = " + (x - y));
    }

    public static void Mul(int x, int y) {
        System.out.println("Mul = " + (x * y));
    }

    public static void Dev(int x, int y) {
        if (y == 0) {
            System.out.println("Cannot divide by zero");
        } else {
            System.out.println("Dev = " + (x / y));
        }
    }

    public static void Rem(int x, int y) {
        if (y == 0) {
            System.out.println("Cannot divide by zero");
        } else {
            System.out.println("Rem = " + (x % y));
        }
    }

    public static void Pow(int x, int y) {
        double result = Math.pow(x, y);
        System.out.println("Pow = " + result);
    }
}
